package BubbleSort;

public class BubbleSortIncreasing {

    public static void main(String[] args) {
        int swap;
        int q=1;
        int lala[] = {82, 12, 41, 38, 19, 26, 9, 48, 20, 55, 8, 32, 3};
        
        System.out.println("Sebelum Pengurutan");
        for (int i = 0; i < lala.length; i++) {
            System.out.print(lala[i]+" ");
        }
        
        for (int i = 0; i < lala.length; i++) {
            for (int j = 0; j < lala.length-q; j++) {
                if (lala[j] > lala[j + 1]) {
                    swap = lala[j];
                    lala[j] = lala[j + 1];
                    lala[j + 1] = swap;
                }
            }
            q++;
        }
        
        System.out.println("\nSetelah Pengurutan");
        for (int i = 0; i < 7; i++) {
            System.out.print(lala[i] + " ");
        }
    }
}