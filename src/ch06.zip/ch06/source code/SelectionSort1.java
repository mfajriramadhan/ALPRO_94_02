package SelectionSort;

public class SelectionSort1 {

    public static void main(String[] args) {
        int a[] = {82, 12, 41, 38, 19, 26, 9, 48, 20, 55, 8, 32, 3};
        int q = 0;
        int r;
        int swap;

        for (int i = 0; i < a.length; i++) {
            r = a[i];
            for (int j = 0 + q; j < a.length - 1; j++) {

                if (a[j + 1] < r) {
                    swap = r;
                    r = a[j + 1];
                    a[j + 1] = swap;
                }
            }
            a[i] = r;
            q++;
        }
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i] + " ");
        }
    }
}